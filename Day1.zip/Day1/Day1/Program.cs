﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b,max;

            Console.WriteLine("enter  a = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter  b = ");
            b = Convert.ToInt32(Console.ReadLine());

            //     12>13 --> max= 13(b)
            //     11>3   -->max=11(a)
            max = ( a>b ) ? a   : b ;
            Console.WriteLine("between {1} & {2} MAX = {0}  ", max,a,b);

        }
    }
}
