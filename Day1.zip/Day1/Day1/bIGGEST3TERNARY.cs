﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    class bIGGEST3TERNARY
    {
        static void Main(string[] args)
        {
            int a, b, c, max;

            Console.WriteLine("enter  a = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter  b = ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter  c = ");
            c = Convert.ToInt32(Console.ReadLine());

            max = (a > b) ? (a > c) ? a : c : (b > c) ? b : c;
            Console.WriteLine("Biggest of {0}  {1} & {2} = {3}", a, b, c, max);
        }
    }
}
