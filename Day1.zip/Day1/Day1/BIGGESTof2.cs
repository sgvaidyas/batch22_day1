﻿using System;

namespace Day1
{
    class BIGGESTof2
    {
        static void Main(string[] args)
        {
            int a, b, c, max;

            Console.WriteLine("enter  a = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter  b = ");
            b = Convert.ToInt32(Console.ReadLine());

            max = (a > b) ? a : b;

            Console.WriteLine("The bigges of 2 numbers {0} & {1} is {2}",a,b,max);

        }
    }
}
